const Navbar = () => {
    return (
        <div>
            navbar
        </div>
    )
}

export default Navbar